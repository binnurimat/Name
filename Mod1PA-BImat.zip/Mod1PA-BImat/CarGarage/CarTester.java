package parkingsystem;

public class CarTester {

    public static void main(String[] args) {

        // Create car objects with make, model, color, and year
        Car car1 = new Car("Toyota", "Camry", "Blue", 2020);  // Added color
        Car car2 = new Car("Honda", "Civic", "Red", 2021);     // Added color
        Car car3 = new Car("Ford", "Mustang", "Black", 2019);  // Added color

        // Create Garage object
        Garage garage = new Garage();

        // Add cars to the garage
        garage.addCar(car1);
        garage.addCar(car2);
        garage.addCar(car3);

        // Display all cars in the garage
        garage.displayCars();

        // Remove a car from the garage
        garage.removeCar(car2);

        // Display all cars again after removal
        garage.displayCars();
    }
}

