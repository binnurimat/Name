package parkingsystem;

import java.util.ArrayList;

public class Garage {
	private ArrayList<Car> cars;

    // Constructor
    public Garage() {
        cars = new ArrayList<>();
    }

    // Method to add a car to the garage
    public void addCar(Car car) {
        cars.add(car);
        System.out.println("Car added to garage: " + car.getMake() + " " + car.getModel());
    }

    // Method to remove a car from the garage
    public void removeCar(Car car) {
        if (cars.contains(car)) {
            cars.remove(car);
            System.out.println("Car removed from garage: " + car.getMake() + " " + car.getModel());
        } else {
            System.out.println("Car not found in garage.");
        }
    }

    // Method to display all cars in the garage
    public void displayCars() {
        if (cars.isEmpty()) {
            System.out.println("No cars in the garage.");
        } else {
            System.out.println("Cars in the garage:");
            for (Car car : cars) {
                car.displayDetails();
                System.out.println("----------------------");
            }
        }
    }
}
